import type { CapacitorConfig } from "@capacitor/cli";

// Wrapper móvil de IPGuard SaaS.
//
// La app instalada es solo una "shell" de ~5 MB. Carga la web real desde
// https://app.ipguard.es. Eso significa que cualquier cambio en el SaaS
// (nuevo módulo, fix de UI, mejora) aparece en el móvil al siguiente
// arranque/refresh sin tener que pasar por App Store / Google Play.
//
// Solo hay que volver a subir a las stores cuando cambian:
//   - Permisos del sistema (cámara, contactos, etc.)
//   - Plugins nativos
//   - Icono / splash / nombre de la app
//   - Versión (CFBundleVersion / versionCode)

const config: CapacitorConfig = {
  // Identificador único en las stores. NO se puede cambiar después de
  // la primera publicación — Apple/Google lo usan como llave primaria.
  appId: "es.ipguard.app",

  // Nombre que el usuario verá bajo el icono en su pantalla principal.
  appName: "IPGuard",

  // Carpeta del bundle web local. Como cargamos remoto vía `server.url`,
  // esto solo se usa como fallback offline y para el splash inicial.
  webDir: "www",

  // Carga remota: la app va directo a tu SaaS en producción. Apple
  // permite esto SIEMPRE Y CUANDO la app tenga valor nativo añadido
  // (push, notificaciones, biométrico, etc. — los plugins instalados).
  server: {
    url: "https://app.ipguard.es",
    // androidScheme: "https" para que en Android el WebView use HTTPS
    // y se cumpla la política Network Security default.
    androidScheme: "https",
    // cleartext: false — bloquea HTTP plano, solo HTTPS. Buena práctica.
    cleartext: false,
  },

  // Configuración por plataforma
  ios: {
    // Esquema custom para deep links (futuros: ipguard://...).
    scheme: "IPGuard",
    // ContentInsetAdjustmentBehavior=automatic respeta safe-area en
    // iPhones con notch / Dynamic Island.
    contentInset: "automatic",
    // Permitir compartir cookies con safari.app — útil si el user
    // tiene sesión en su Safari y abre la app por primera vez.
    limitsNavigationsToAppBoundDomains: false,
  },

  android: {
    // allowMixedContent: false → si el SaaS sirve algún recurso por HTTP
    // (no debería) lo bloquea. Mejor seguro.
    allowMixedContent: false,
    // captureInput: true → el WebView captura los inputs nativos (cámara,
    // archivos), respetando los permisos que el user concede.
    captureInput: true,
  },

  plugins: {
    SplashScreen: {
      // Splash visible 1500ms con fade. Después el WebView toma control.
      launchShowDuration: 1500,
      launchAutoHide: true,
      backgroundColor: "#0a0e27",  // mismo tono que el cover IPGuard
      androidScaleType: "CENTER_CROP",
      showSpinner: true,
      iosSpinnerStyle: "small",
      spinnerColor: "#a78bfa",
    },
    StatusBar: {
      // Texto blanco sobre fondo oscuro (matching brand).
      style: "DARK",
      backgroundColor: "#0a0e27",
      overlaysWebView: false,
    },
    PushNotifications: {
      // El usuario recibe una alerta + sonido + badge. iOS pide
      // permiso al primer arranque vía PushNotifications.requestPermissions().
      presentationOptions: ["badge", "sound", "alert"],
    },
  },
};

export default config;
