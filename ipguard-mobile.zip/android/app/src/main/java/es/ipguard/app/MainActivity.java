package es.ipguard.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
