# IPGuard Móvil — Guía completa para subir a App Store y Google Play

Esta carpeta (`/var/www/CaaS/ipguard-mobile`) contiene un wrapper Capacitor que carga `https://app.ipguard.es` dentro de una app nativa. Una vez publicada en las stores, **todos los cambios que hagas en el SaaS aparecen automáticamente** en la app sin tener que volver a subir nada — solo necesitas pasar review cuando toques el wrapper en sí (icono, permisos, splash, plugins).

> **Importante**: este proyecto se desarrolla en el servidor pero **iOS solo se puede compilar en un Mac**. Tendrás que clonar/copiar la carpeta a tu Mac para compilar y subir a App Store. Android Studio funciona en cualquier OS pero también requiere instalación local.

---

## 1. Cuentas que necesitas comprar

| Servicio | Coste | Para qué |
|----------|-------|----------|
| **Apple Developer Program** | **$99/año** | Subir a App Store |
| **Google Play Developer** | **$25 una vez** | Subir a Google Play |
| **Firebase (FCM)** | Gratis | Push notifications Android |

Apple es la cara — paga $99 y tienes acceso a la consola.
Google Play es de pago único $25 — luego puedes publicar todas las apps que quieras.

---

## 2. Pasar el proyecto a tu Mac (para iOS)

Desde tu Mac:

```bash
# Opción A — clonar desde el servidor con SCP
scp -r jesus@app.ipguard.es:/var/www/CaaS/ipguard-mobile ~/Desarrollo/

# Opción B — pasarlo a Git y clonarlo en el Mac
# (en el servidor)
cd /var/www/CaaS/ipguard-mobile
git init && git add -A && git commit -m "ipguard mobile wrapper"
# luego push a tu repo privado y clone en Mac
```

Una vez en el Mac:

```bash
cd ~/Desarrollo/ipguard-mobile
npm install
npx cap sync
```

Necesitas tener instalado:
- **Xcode 15+** (gratis, App Store)
- **CocoaPods** (`sudo gem install cocoapods`)
- **Node.js 20+**

---

## 3. Apple Developer + iOS

### 3.1 Crear el App ID en Apple Developer

1. Ve a https://developer.apple.com/account
2. **Identifiers → +** → App IDs → App
3. Description: `IPGuard`
4. **Bundle ID (Explicit)**: `es.ipguard.app` ← debe coincidir con `appId` de `capacitor.config.ts`
5. Capabilities: marca **Push Notifications** (lo necesitamos) y **Sign in with Apple** (recomendado)
6. Continue → Register

### 3.2 Generar APNs Key (para push)

1. Apple Developer → **Keys → +**
2. Name: `IPGuard APNs`
3. Marca **Apple Push Notifications service (APNs)**
4. Continue → Register → **Download** el `.p8` (solo se descarga una vez, guárdalo)
5. Apunta el **Key ID** (10 caracteres) y tu **Team ID** (10 caracteres, en la esquina superior derecha)

### 3.3 Abrir en Xcode

```bash
cd ~/Desarrollo/ipguard-mobile
npx cap open ios
```

Xcode se abre con `App.xcworkspace`. Ahora:

1. Click en `App` (raíz del proyecto en el panel izquierdo)
2. Pestaña **Signing & Capabilities**
3. **Team**: selecciona tu Apple Developer Team
4. **Bundle Identifier**: verifica que es `es.ipguard.app`
5. Click **+ Capability** → **Push Notifications**
6. Click **+ Capability** → **Background Modes** → marca **Remote notifications**

### 3.4 Compilar y probar en simulador

1. En el toolbar superior selecciona un simulador (iPhone 15 Pro, etc.)
2. Pulsa **Play** (▶)
3. La app debería abrir mostrando el splash IPGuard y luego cargar `app.ipguard.es`

### 3.5 Subir a App Store Connect

1. **Product → Archive** (con un dispositivo real conectado, no simulador)
2. Espera a que compile en modo Release
3. Window → Organizer → selecciona el archive más reciente
4. **Distribute App → App Store Connect → Upload**
5. Sigue los pasos del wizard, **Upload**

### 3.6 Publicar en App Store

1. Ve a https://appstoreconnect.apple.com
2. **My Apps → +** → New App
3. Platform: iOS · Name: `IPGuard` · Primary Language: Spanish · Bundle ID: el que registraste
4. SKU: `IPGUARD-IOS-001`
5. **App Information**:
   - Categoría: Business
   - Privacy Policy URL: `https://ipguard.es/politica-privacidad`
6. **Pricing**: Free (tu modelo es subscription dentro de la app, no IAP)
7. **App Privacy**: declara qué datos recolecta (email, name, contact info)
8. **App Review Information**:
   - Demo account: usuario de prueba (`demo@ipguard.es` con contraseña, debe estar creado)
   - Notes: "App para gestionar workspace IPGuard. Login vía Cloudflare Access."
9. **Version 1.0.0**: añade screenshots (mínimo 6.5", 5.5"), description, keywords
10. **Build**: selecciona el que subiste por Xcode
11. **Submit for Review**

⏱️ **Tiempo de review**: 24-48h media. Si rechazan, te dicen por qué y vuelves a subir.

> ⚠️ Apple puede rechazar apps que sean "solo wrapper de web". Para evitarlo, asegúrate de que:
> - Push notifications están funcionando
> - Hay funciones nativas usadas (las tienes: Push, StatusBar, SplashScreen)
> - El TestFlight build se descarga y abre correctamente

---

## 4. Google Play + Android

### 4.1 Crear cuenta de Google Play Developer

1. https://play.google.com/console → paga $25
2. Verifica tu identidad (DNI/passport)
3. Crea organización o developer individual

### 4.2 Generar Firebase project (para FCM push)

1. https://console.firebase.google.com → **Add project** → IPGuard
2. Disable Google Analytics (opcional, no nos hace falta)
3. **Project Settings → Cloud Messaging** (engranaje arriba)
4. Apunta el **Server key** y el **Sender ID**

### 4.3 Configurar Android

```bash
cd ipguard-mobile
npx cap open android
```

Android Studio se abre. Espera a que sincronice Gradle (~2 min primera vez).

1. **app/build.gradle** → verifica `applicationId "es.ipguard.app"`
2. **app/src/main/AndroidManifest.xml** → ya tiene los permisos de internet
3. Conecta un dispositivo Android (o usa el emulator) y dale **Run** (▶)

### 4.4 Generar AAB (Android App Bundle)

1. **Build → Generate Signed Bundle / APK → Android App Bundle → Next**
2. Si es la primera vez:
   - **Create new keystore**
   - Path: guarda en sitio seguro (ej. `~/Documents/keystores/ipguard-release.jks`)
   - Password: una segura, **GUÁRDALA** (la perderás → la app está muerta)
   - Alias: `ipguard-release`
   - Validity: 25 años (Google requiere mínimo)
   - First/Last name + organización + ciudad + país
3. **Build variants: release**
4. Espera. Android Studio te dice dónde está el `.aab` (en `app/release/`)

### 4.5 Subir a Google Play Console

1. https://play.google.com/console → **Create app**
2. App name: IPGuard · Default language: Spanish · App or game: App · Free or paid: Free
3. **Set up your app**:
   - App access: tienes login required → indica las credenciales demo
   - Ads: No
   - Content rating: rellena cuestionario (Business, sin contenido sensible)
   - Target audience: 18+ (B2B)
   - News app: No
   - COVID-19 contact tracing: No
   - Data safety: declara qué recolectas (igual que en Apple)
4. **Production → Create new release**
5. Sube el `.aab` de antes
6. Release notes: "Versión inicial"
7. **Review release → Start rollout to Production**

⏱️ **Tiempo de review**: 1-3 días primera vez, luego horas.

---

## 5. Cómo se actualiza después de publicar

### 5.1 Cambios en el SaaS web (lo que harás a diario)

```bash
# En el servidor
cd /var/www/CaaS/ipguard-saas
# editas código
sudo -u caas npm run build && sudo -u caas pm2 restart caas
```

✅ **Listo**. Los users con la app instalada lo verán al siguiente arranque/refresh. **NO** necesitas tocar nada en App Store Connect ni Google Play Console.

### 5.2 Cambios del wrapper (raro, 1-3 veces al año)

Cuando cambies icono, splash, plugins, permisos, versión mínima OS:

```bash
# En tu Mac
cd ipguard-mobile
# editas capacitor.config.ts o resources/icon.png
npx capacitor-assets generate    # si tocaste icono/splash
npx cap sync

# iOS
npx cap open ios  # → bump version en Xcode → Archive → Upload
# Android
npx cap open android  # → bump versionCode en build.gradle → Generate Signed Bundle → Upload
```

Sigue exactamente los mismos pasos que en la primera submission, pero indica que es **versión 1.0.1** (etc.) y describe qué cambia en release notes.

### 5.3 Hotfix urgente (si quieres OTA sin store)

Para esto hay que añadir **Capacitor Live Updates** (Ionic, $499/año plan team o gratis con límites). No está incluido en este proyecto inicial. Si lo quieres, te lo monto en otra sesión.

---

## 6. Mantener el bundle ID y secrets

**NO PIERDAS NUNCA:**
- El `.p8` de APNs Key (push iOS)
- El `.jks` keystore Android + su password
- Las credenciales de tu Apple Developer + Google Play Console
- El `appId: "es.ipguard.app"` — si lo cambias después de publicar, Apple/Google considera que es OTRA app y los users tienen que reinstalar.

**Backup recomendado**: guarda los `.p8`, `.jks` y passwords en 1Password (ya lo tienes integrado en IPGuard) o en disco cifrado.

---

## 7. Estructura del proyecto

```
ipguard-mobile/
├── capacitor.config.ts        # config principal — appId, name, splash, etc.
├── package.json               # deps Capacitor + plugins
├── resources/                 # icon-only.svg + splash.svg fuente
│   ├── icon-only.svg          # vector 1024x1024 (lo edita Inkscape/Figma)
│   ├── icon-only.png          # render PNG para Capacitor Assets
│   ├── splash.svg             # vector 2732x2732
│   └── splash.png             # render PNG
├── www/                       # fallback offline cuando no hay red
│   └── index.html
├── ios/                       # proyecto Xcode (NO EDITAR a mano, regenerable)
│   └── App/App.xcworkspace
├── android/                   # proyecto Android Studio (NO editar a mano)
│   └── app/
└── SUBIR-A-STORES.md          # esta guía
```

---

## 8. Checklist antes de subir

### iOS (App Store)
- [ ] Bundle ID `es.ipguard.app` en Xcode coincide con Apple Developer Identifier
- [ ] Push Notifications capability añadida
- [ ] APNs `.p8` generado y guardado
- [ ] Icono visible en home screen (probado en simulator)
- [ ] App carga `app.ipguard.es` correctamente
- [ ] TestFlight build descargado y probado en iPhone real
- [ ] Privacy Policy URL accesible: `https://ipguard.es/politica-privacidad`
- [ ] Demo account creado para Apple reviewer
- [ ] Screenshots subidos (6.5" y 5.5")
- [ ] Description en App Store Connect

### Android (Google Play)
- [ ] applicationId `es.ipguard.app` en `app/build.gradle`
- [ ] Firebase project creado, Sender ID anotado
- [ ] AAB generado y firmado
- [ ] Keystore guardado en sitio seguro
- [ ] Privacy Policy URL accesible
- [ ] Data safety form completado
- [ ] Content rating cuestionario respondido
- [ ] Screenshots subidos
- [ ] Description en Google Play Console

---

## 9. Apoyo / Dudas

Cuando estés en el Mac y te atasques con algún paso, dímelo (con copia del error o screenshot) y te lo resuelvo. Lo más típico que se atasca es:

1. **"Code signing error" en Xcode** → falta seleccionar Team o el provisioning profile no se ha creado. Solución: en Signing & Capabilities marcar "Automatically manage signing" y elegir tu Team.
2. **"Could not find tools.jar" en Android Studio** → instala JDK 17 (no usa el del sistema, usa el de Android Studio). En Android Studio: File → Project Structure → SDK Location → JDK location: el built-in.
3. **"Invalid bundle - Push capability missing"** → vuelve a 3.3 paso 5/6 (capabilities).

Buena suerte 🚀
