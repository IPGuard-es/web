import type { CapacitorConfig } from "@capacitor/cli";

// Wrapper móvil de IPGuard SaaS.
//
// FLUJO DE AUTENTICACIÓN (clave para entender la arquitectura):
//
// 1. App arranca → carga `www/index.html` LOCAL (no remoto). Por eso no hay
//    `server.url`. El index muestra una pantalla de login con un botón.
// 2. Usuario pulsa "Iniciar sesión".
// 3. App abre `https://app.ipguard.es/api/mobile/auth/bridge` en
//    SFSafariViewController vía `@capacitor/browser`.
// 4. Cloudflare Access intercepta y fuerza login (Auth0 con email+password
//    o Google). El usuario completa el login DENTRO de Safari (donde sí
//    funcionan las cookies cross-domain, a diferencia del WKWebView).
// 5. El bridge endpoint del SaaS firma un Mobile JWT (HS256, 30 días) y
//    redirige a `ipguard://auth-callback?token=<JWT>`.
// 6. iOS ve el custom scheme registrado y enruta a la app vía `appUrlOpen`.
// 7. El JS de la app extrae el token, lo guarda en localStorage, cierra
//    Safari y navega el WebView a:
//      `https://mobile.ipguard.es/api/mobile/auth/set-cookie?token=<JWT>`
//    que setea la cookie CF_Authorization y redirige a /dashboard.
// 8. mobile.ipguard.es NO está detrás de Cloudflare Access — la cookie con
//    el Mobile JWT basta para que el SaaS reconozca al usuario (vía el
//    dual-verify en lib/cloudflare-access.ts).
//
// Para actualizar el SaaS web NO hay que volver a subir a las stores. Solo
// cuando se cambia: icono, splash, plugins, permisos, custom URL scheme,
// o esta config.

const config: CapacitorConfig = {
  appId: "es.ipguard.app",
  appName: "IPGuard",

  // Carpeta de assets locales. Es el ENTRY POINT de la app móvil — al no
  // tener `server.url`, Capacitor sirve `www/index.html` desde el bundle.
  webDir: "www",

  server: {
    // No `url` aquí: la app inicia desde www/index.html (pantalla de login).
    // Una vez autenticado, el JS navega a https://mobile.ipguard.es vía
    // window.location.href. Como mobile.ipguard.es NO está en allowNavigation,
    // se abre dentro del WebView con todos los permisos web normales.
    androidScheme: "https",
    cleartext: false,
    // Dominios a los que el WebView puede navegar. Sin esto, intentos de
    // ir a urls externas se bloquean. mobile.ipguard.es es donde corre el
    // SaaS para móviles. app.ipguard.es se abre solo en SFSafariViewController
    // (vía @capacitor/browser), no necesita estar aquí.
    allowNavigation: [
      "mobile.ipguard.es",
      "ipguard.es",
    ],
  },

  ios: {
    // ContentInset=automatic respeta safe-area en iPhones con notch.
    contentInset: "automatic",
    // App-Bound Domains: para móvil-host (mobile.ipguard.es) no necesitamos
    // el truco — al no haber redirecciones cross-domain en el flujo del
    // WebView (solo cookie + dashboard), basta `false` que es menos
    // restrictivo y permite navegación general.
    limitsNavigationsToAppBoundDomains: false,
  },

  android: {
    allowMixedContent: false,
    captureInput: true,
  },

  plugins: {
    SplashScreen: {
      launchShowDuration: 1500,
      launchAutoHide: true,
      // Fondo blanco para hacer match con el icono iPG (negro sobre blanco).
      backgroundColor: "#ffffff",
      androidScaleType: "CENTER_CROP",
      showSpinner: true,
      iosSpinnerStyle: "small",
      spinnerColor: "#000000",
    },
    StatusBar: {
      // Texto oscuro sobre fondo blanco (matching iPG icon).
      style: "LIGHT",
      backgroundColor: "#ffffff",
      overlaysWebView: false,
    },
    PushNotifications: {
      presentationOptions: ["badge", "sound", "alert"],
    },
  },
};

export default config;
