// Login flow para el wrapper IPGuard Mobile.
//
// Este archivo se ejecuta cuando la app abre `www/index.html` en el WKWebView.
// Su trabajo es:
//   1. Comprobar si ya hay un Mobile JWT guardado (de un login previo).
//      - Si sí → ir directo a mobile.ipguard.es con la cookie seteada.
//      - Si no → mostrar botón de login.
//   2. Cuando el user pulsa el botón:
//      a) Abrir SFSafariViewController con la URL del bridge en app.ipguard.es.
//      b) El user autentica vía Cloudflare Access (Auth0 + Google/email).
//      c) El bridge mintea un Mobile JWT y redirige a ipguard://auth-callback?token=XXX.
//      d) iOS enruta el custom scheme a la app vía `appUrlOpen`.
//      e) El listener extrae el token, lo guarda, cierra Safari y navega a
//         mobile.ipguard.es/api/mobile/auth/set-cookie?token=XXX.
//      f) El SaaS setea la cookie y redirige a /dashboard.

const BRIDGE_URL = "https://app.ipguard.es/api/mobile/auth/bridge";
const SET_COOKIE_URL = "https://mobile.ipguard.es/api/mobile/auth/set-cookie";
const STORAGE_KEY = "ipguard_mobile_jwt";
const CALLBACK_SCHEME = "ipguard://auth-callback";

const $btn = document.getElementById("loginBtn");
const $err = document.getElementById("errBox");

function showError(msg) {
  $err.textContent = msg;
  $err.classList.add("show");
}

function clearError() {
  $err.classList.remove("show");
}

function setLoading(loading) {
  if (loading) {
    $btn.disabled = true;
    $btn.innerHTML = '<span class="spinner"></span>Autenticando...';
  } else {
    $btn.disabled = false;
    $btn.textContent = "Iniciar sesión";
  }
}

// Naviga a mobile.ipguard.es con el token en la URL del set-cookie endpoint.
// El SaaS valida, setea la cookie via Set-Cookie y redirige a /dashboard.
// A partir de ahí el WebView recibe la cookie en cada request y todo funciona.
function navigateToSaaS(token) {
  const url = `${SET_COOKIE_URL}?token=${encodeURIComponent(token)}`;
  window.location.href = url;
}

// Si ya tenemos un token guardado, intentamos entrar directo.
// Si está caducado el SaaS responderá 401 y volveremos al login.
function checkExistingSession() {
  const stored = localStorage.getItem(STORAGE_KEY);
  if (stored && stored.length > 50) {
    setLoading(true);
    navigateToSaaS(stored);
  }
}

async function startLogin() {
  clearError();

  if (!window.Capacitor || !window.Capacitor.Plugins) {
    showError("Esta pantalla solo funciona dentro de la app de IPGuard.");
    return;
  }

  const Browser = window.Capacitor.Plugins.Browser;
  if (!Browser) {
    showError("Plugin Browser no disponible. Reinstala la app.");
    return;
  }

  setLoading(true);

  try {
    await Browser.open({
      url: BRIDGE_URL,
      // En iOS abre SFSafariViewController. Se cierra solo cuando el JS
      // detecta el deep-link y llama a Browser.close().
      presentationStyle: "fullscreen",
      windowName: "_self",
    });
  } catch (e) {
    setLoading(false);
    showError("No se pudo abrir el navegador para login: " + (e?.message || e));
  }
}

// Listener del deep link ipguard://auth-callback?token=XXX
// Lo registramos al inicio para no perdernos el callback.
function registerDeepLinkListener() {
  if (!window.Capacitor || !window.Capacitor.Plugins) return;
  const App = window.Capacitor.Plugins.App;
  const Browser = window.Capacitor.Plugins.Browser;
  if (!App) return;

  App.addListener("appUrlOpen", async (data) => {
    const url = data?.url || "";
    if (!url.startsWith(CALLBACK_SCHEME)) return;

    try {
      const u = new URL(url);
      const token = u.searchParams.get("token");
      if (!token) {
        setLoading(false);
        showError("Login completado pero sin token en la respuesta.");
        return;
      }

      // Guarda token para futuros arranques
      localStorage.setItem(STORAGE_KEY, token);

      // Cierra el SFSafariViewController (en iOS funciona)
      try { await Browser?.close(); } catch (_) { /* iOS lo cierra solo a veces */ }

      // Navega al SaaS con la cookie set vía endpoint
      navigateToSaaS(token);
    } catch (e) {
      setLoading(false);
      showError("Error procesando login: " + (e?.message || e));
    }
  });
}

// Bind del botón
$btn.addEventListener("click", startLogin);

// Init
registerDeepLinkListener();
checkExistingSession();
